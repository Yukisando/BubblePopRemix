﻿using System.Collections;
using TMPro;
using UnityEngine;

public class Bubble : MonoBehaviour
{

    //Requirements
    private Rigidbody2D _rigidbody;
    private CircleCollider2D _circleCollider;
    private LevelManager _levelManager;
    private TextMeshPro _valueText;
    private SpriteRenderer _spriteRenderer;
    private GameObject _trail;

    //Assignments
    [SerializeField] private int allowedBounces = 1;

    //Properties
    private int _bounces;

    //Values
    private int _value;

    private void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _rigidbody = GetComponent<Rigidbody2D>();
        _circleCollider = GetComponent<CircleCollider2D>();
        _levelManager = FindObjectOfType<LevelManager>();
        _valueText = GetComponentInChildren<TextMeshPro>();
        _trail = GetComponentInChildren<ParticleSystem>().gameObject;

        transform.localScale = Vector3.zero;
    }

    private void Start()
    {
        var i = Random.Range(1, 7); //Should slowly increase to 11
        SetValue((int) Mathf.Pow(2, i));

        _spriteRenderer.color = UIManager.Current.GetColor(_value);
        StartCoroutine(Grow());
    }

    private IEnumerator Grow()
    {

        AudioManager.Current.PlayGrow();
        while (transform.localScale.x <= 1)
        {
            yield return new WaitForEndOfFrame();
            transform.localScale += Vector3.one * .13f;
        }

        transform.localScale = Vector3.one;
    }

    private void OnBecameInvisible()
    {
        Destroy(gameObject);
        LevelManager.InProgress = false;
    }

    private void BecomeTile()
    {
        Destroy(this);
        var newBubbleTile = gameObject.AddComponent<BubbleTile>();
        transform.position = _levelManager.GetClosestPosition(transform.position, newBubbleTile);
        ClearTrail();
        AudioManager.Current.PlayNoMatch();
        _rigidbody.velocity = Vector3.zero;
        name = "TileBubble";
        _rigidbody.isKinematic = true;
        _circleCollider.sharedMaterial = null;
        newBubbleTile.SetValue(_value);
        transform.SetParent(_levelManager.transform);
        tag = "BubbleTile";
        if (gameObject.transform.position.y < _levelManager.levelLimit.position.y) _levelManager.GameOver();
        newBubbleTile.CheckSurroundings();
        LevelManager.InProgress = false;
    }

    private void OnCollisionEnter2D(Collision2D _col)
    {
        var collidedBubbleTile = _col.gameObject.GetComponent<BubbleTile>();

        if (!collidedBubbleTile)
        {
            _bounces++;
            AudioManager.Current.PlayWallHit();
            if (_bounces >= allowedBounces + 1)
            {
                LevelManager.InProgress = false;
                Destroy(gameObject);
            }

            return;
        }

        //A Bubble was found
        if (collidedBubbleTile.GetValue() == _value)
        {
            //It's a match!
            Match(collidedBubbleTile);
            return;
        }

        //The bubble becomes a SpawnedBubble
        BecomeTile();
    }

    private void Match(BubbleTile _collidedBubbleTile)
    {
        Destroy(gameObject);
        AudioManager.Current.PlayMatch();
        _levelManager.AddScore(_collidedBubbleTile.GetValue());
        _collidedBubbleTile.CheckSurroundings();
        _collidedBubbleTile.SetValue(_value * 2);
        ParticleManager.Current.PlayMatch(_collidedBubbleTile.transform.position);
        LevelManager.InProgress = false;
    }

    private void SetValue(int _value)
    {
        this._value = _value;
        _valueText.text = _value.ToString();
    }

    private void OnDestroy()
    {
        _trail.transform.SetParent(transform.parent);
        _trail.GetComponent<ParticleSystem>().Stop();
    }

    private void ClearTrail()
    {

        _trail.transform.SetParent(transform.parent);
        _trail.GetComponent<ParticleSystem>().Stop();
    }

}