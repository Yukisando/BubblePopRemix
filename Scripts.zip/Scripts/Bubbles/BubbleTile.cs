﻿using System.Linq;
using TMPro;
using UnityEngine;

public class BubbleTile : MonoBehaviour
{

    //Requirement
    private TextMeshPro _valueText;
    private LevelManager _levelManager;
    private SpriteRenderer _spriteRenderer;

    //Properties
    [SerializeField] private float chainReactionDistance = 1f;
    [HideInInspector] public bool spawnedTile;
    private int _value;

    private void Awake()
    {
        _levelManager = FindObjectOfType<LevelManager>();
        _valueText = GetComponentInChildren<TextMeshPro>();
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        if (!spawnedTile) return;

        var i = Random.Range(1, 5); //Should slowly increase to 11
        SetValue((int) Mathf.Pow(2, i));
    }

    public void SetValue(int _value)
    {
        this._value = _value;
        _valueText.text = _value.ToString();

        _spriteRenderer.color = UIManager.Current.GetColor(_value);

        if (_value >= 2048) Explode();
    }

    private void Explode()
    {
        LevelManager.InProgress = true;
        foreach (var tile in _levelManager.activeTiles.Keys.ToList())
            if (tile && tile != this)
                if (Vector3.Distance(tile.transform.position, transform.position) < chainReactionDistance * 2)
                {
                    //There is a match!
                    Destroy(gameObject);
                    Destroy(tile.gameObject);
                    AudioManager.Current.PlayChainMatch();
                    _levelManager.AddScore(tile.GetValue());

                    ParticleManager.Current.PlayMatch(transform.position);
                    _levelManager.activeTiles.Remove(this);
                    _levelManager.activeTiles.Remove(tile);
                    _levelManager.freeSlots.Add(transform.position);
                    _levelManager.freeSlots.Add(tile.transform.position);
                }

        LevelManager.InProgress = false;
    }

    public int GetValue() => _value;

    public void CheckSurroundings()
    {
        LevelManager.InProgress = true;
        foreach (var tile in _levelManager.activeTiles.Keys.ToList())
            if (tile && tile != this)
                if (Vector3.Distance(tile.transform.position, transform.position) < chainReactionDistance)
                    if (tile.GetValue() == _value)
                    {
                        //There is a match!
                        Destroy(gameObject);
                        AudioManager.Current.PlayChainMatch();
                        _levelManager.AddScore(tile.GetValue());
                        tile.SetValue(tile.GetValue() * 2);
                        tile.CheckSurroundings(); //Chain reaction
                        _levelManager.activeTiles.Remove(this);
                        ParticleManager.Current.PlayMatch(transform.position);
                        _levelManager.freeSlots.Add(transform.position);

                        //break; //dis-allows group chain reaction
                    }

        LevelManager.InProgress = false;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(transform.position, chainReactionDistance);
    }

}