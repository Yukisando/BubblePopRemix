﻿using UnityEngine;

public class AudioManager : MonoBehaviour
{

    //Singleton
    public static AudioManager Current;

    private AudioSource _source;
    [SerializeField] private AudioClip launchClip, wallHitClip, matchClip, chainMatchClip, nomatchClip, winClip, loseClip, growClip;

    private void Awake()
    {
        if (Current != this && Current != null) Destroy(this);
        if (Current == null) Current = this;

        _source = GetComponent<AudioSource>();
    }

    public void PlayWallHit()
    {
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);
        _source.PlayOneShot(wallHitClip);
    }

    public void PlayMatch()
    {
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);

        _source.PlayOneShot(matchClip);
    }

    public void PlayChainMatch()
    {
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);

        if (!_source.isPlaying)
            _source.PlayOneShot(chainMatchClip);
    }

    public void PlayNoMatch()
    {
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);

        _source.PlayOneShot(nomatchClip);
    }

    public void PlayWin()
    {
        _source.volume -= .5f;
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);

        _source.PlayOneShot(winClip);
        _source.volume += .5f;
    }

    public void PlayLose()
    {
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);

        _source.PlayOneShot(loseClip);
        _source.volume += .5f;
    }

    public void PlayLaunch()
    {
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);

        _source.PlayOneShot(launchClip);
    }

    public void PlayGrow()
    {
        if (!_source.isPlaying) _source.pitch = Random.Range(0.9f, 1.1f);

        _source.PlayOneShot(growClip);
    }

}