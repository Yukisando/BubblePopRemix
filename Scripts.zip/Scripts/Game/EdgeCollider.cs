﻿using UnityEngine;

public class EdgeCollider : MonoBehaviour
{

    private Camera _screen;

    private void Awake()
    {
        _screen = FindObjectOfType<Camera>();
    }

    private void Start()
    {
        GenerateCollidersAcrossScreen();
    }

    private void GenerateCollidersAcrossScreen()
    {
        Vector2 lDCorner = _screen.ViewportToWorldPoint(new Vector3(0, 0f, _screen.nearClipPlane));
        Vector2 rUCorner = _screen.ViewportToWorldPoint(new Vector3(1f, 1f, _screen.nearClipPlane));
        Vector2[] colliderpoints;

        var leftEdge = new GameObject("leftEdge").AddComponent<EdgeCollider2D>();
        leftEdge.transform.SetParent(transform);
        leftEdge.tag = "Wall";
        colliderpoints = leftEdge.points;
        colliderpoints[0] = new Vector2(lDCorner.x, lDCorner.y - 4);
        colliderpoints[1] = new Vector2(lDCorner.x, rUCorner.y + 4);
        leftEdge.points = colliderpoints;

        var rightEdge = new GameObject("rightEdge").AddComponent<EdgeCollider2D>();
        rightEdge.transform.SetParent(transform);
        rightEdge.tag = "Wall";
        colliderpoints = rightEdge.points;
        colliderpoints[0] = new Vector2(rUCorner.x, rUCorner.y + 4);
        colliderpoints[1] = new Vector2(rUCorner.x, lDCorner.y - 4);
        rightEdge.points = colliderpoints;

        var upperEdge = new GameObject("upperEdge").AddComponent<EdgeCollider2D>();
        upperEdge.transform.SetParent(transform);
        upperEdge.tag = "Wall";
        colliderpoints = upperEdge.points;
        colliderpoints[0] = new Vector2(lDCorner.x - 4, rUCorner.y);
        colliderpoints[1] = new Vector2(rUCorner.x + 4, rUCorner.y);
        upperEdge.points = colliderpoints;

        var lowerEdge = new GameObject("lowerEdge").AddComponent<EdgeCollider2D>();
        lowerEdge.transform.SetParent(transform);
        lowerEdge.tag = "Wall";
        colliderpoints = lowerEdge.points;
        colliderpoints[0] = new Vector2(lDCorner.x - 4, lDCorner.y);
        colliderpoints[1] = new Vector2(rUCorner.x + 4, lDCorner.y);
        lowerEdge.points = colliderpoints;
    }

}