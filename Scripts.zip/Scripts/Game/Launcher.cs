﻿using UnityEngine;

public class Launcher : MonoBehaviour
{

    //Requirements
    private Camera _cam;
    private LauncherDisplay _launcherDisplay;

    //Assignments
    [SerializeField] private Bubble pfBubble;

    //Properties
    [SerializeField] private float force = 80f;
    private Bubble _currentBubble;

    //Mouse settings
    private bool _isHolding;
    private Vector3 _startMousePosition;

    private void Awake()
    {
        _cam = FindObjectOfType<Camera>();
        _launcherDisplay = GetComponent<LauncherDisplay>();
    }

    private void Start()
    {
        _isHolding = false;
    }

    private void Update()
    {
        if (LevelManager.InProgress || LevelManager.Gameover || !LevelManager.GameStarted) return;

        var mouseWorldPosition = _cam.ScreenToWorldPoint(Input.mousePosition);
        mouseWorldPosition.z = 0; //Ignores the camera's plane distance

        if (Input.GetMouseButtonDown(0) && !_isHolding)
        {
            //The player has pressed down on the screen and isn't already holding any bubble
            _startMousePosition = mouseWorldPosition;
            BeginDrag();
        }

        if (Input.GetMouseButton(0) && _isHolding)
        {
            //The player is holding a bubble
            var reversedDirection = mouseWorldPosition - _startMousePosition;
            var length = Mathf.Clamp(Vector3.Distance(_startMousePosition, mouseWorldPosition), 0, 3);
            _launcherDisplay.EndPosition(transform.position - _launcherDisplay.length * length * reversedDirection.normalized);
        }

        if (!Input.GetMouseButton(0) && _isHolding)

            //The player has released a bubble
            Release(mouseWorldPosition);
    }

    private void BeginDrag()
    {
        _launcherDisplay.StartPosition(transform.position);
        _isHolding = true;
        _currentBubble = Instantiate(pfBubble, transform.position, Quaternion.identity, transform);
        _launcherDisplay.Show();
    }

    private void Release(Vector3 _endMousePosition)
    {
        var launchDirection = (_startMousePosition - _endMousePosition).normalized;
        if (launchDirection.magnitude <= 0.01f) launchDirection = Vector3.up;
        _isHolding = false;

        //Launch the bubble
        _currentBubble.GetComponent<Rigidbody2D>().AddForce(launchDirection * force, ForceMode2D.Impulse);

        AudioManager.Current.PlayLaunch();
        _currentBubble = null;
        _launcherDisplay.Hide();
        LevelManager.InProgress = true;
    }

}