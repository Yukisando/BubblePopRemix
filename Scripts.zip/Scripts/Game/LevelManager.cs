﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelManager : MonoBehaviour
{

    //Parameters
    [SerializeField] private float waveLength = 4f;
    [SerializeField] private BubbleTile pfBubbleTile;
    [SerializeField] [Range(1, 15)] private int columns = 7;
    [SerializeField] [Range(1, 15)] private int rows = 2;
    [SerializeField] [Range(0, 2048)]
    public int goal = 500;
    public Transform levelLimit;

    //Data
    private int _score;
    public Dictionary<BubbleTile, Vector3> activeTiles = new Dictionary<BubbleTile, Vector3>();
    public List<Vector3> freeSlots = new List<Vector3>();

    //Settings
    public static bool Gameover;
    public static bool GameStarted;
    public static bool InProgress;
    private float _waveTimer;

    private void Awake()
    {
        Gameover = false;
        GameStarted = false;
        InProgress = false;
    }

    private void Start()
    {
        GenerateLevel();
        UIManager.Current.SetGoal(goal);
        UIManager.Current.SetTimerMax(waveLength);
        _waveTimer = 0;
        StartCoroutine(AddRow());
        GameStarted = true;
    }

    private void LateUpdate()
    {
        if (Gameover) return;
        _waveTimer += Time.deltaTime;
        UIManager.Current.SetTimer(_waveTimer);
    }

    // ReSharper disable once FunctionRecursiveOnAllPaths
    private IEnumerator AddRow()
    {
        yield return new WaitForSeconds(waveLength);
        _waveTimer = 0;

        //Move level down
        foreach (var tile in activeTiles.Keys.ToList())
        {
            if (!tile) continue;
            var newPosition = tile.gameObject.transform.position += Vector3.down;
            if (newPosition.y < levelLimit.position.y) GameOver();
            activeTiles[tile] = newPosition;
            freeSlots.Remove(newPosition);
        }

        //Generate row
        for (var i = 0; i < columns; i++)
        {
            var tilePosition = transform.position + new Vector3(i + 1, -1, 0);
            var tile = Instantiate(pfBubbleTile, tilePosition, Quaternion.identity, transform);
            ;
            tile.spawnedTile = true;
            activeTiles.Add(tile, tilePosition);
        }

        StartCoroutine(AddRow());
    }

    public void AddScore(int _amount)
    {
        _score += (int) (_amount / 1.5f);
        UIManager.Current.SetProgress(_score);
        if (_score >= goal) Win();
        CheckBoard();
    }

    private void CheckBoard()
    {
        if (activeTiles.Count == 0) UIManager.Current.ShowPerfectPanel();
    }

    private void Win()
    {
        Gameover = true;
        UIManager.Current.ShowWinPanel(true);
        StopAllCoroutines();
        AudioManager.Current.PlayWin();
        StartCoroutine(Restart());
    }

    public void GameOver()
    {
        Gameover = true;
        UIManager.Current.ShowGameOverPanel(true);
        StopAllCoroutines();
        AudioManager.Current.PlayLose();
        StartCoroutine(Restart());
    }

    private static IEnumerator Restart()
    {
        yield return new WaitForSeconds(2f);
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    private void GenerateLevel()
    {
        for (var col = 0; col < columns; col++)
        for (var row = 0; row < rows; row++)
        {
            var tilePosition = transform.position + new Vector3(col + 1, -(row + 1), 0);
            var tile = Instantiate(pfBubbleTile, tilePosition, Quaternion.identity, transform);
            ;
            tile.spawnedTile = true;
            activeTiles.Add(tile, tilePosition);
        }

        for (var col = 0; col < 7; col++)
        for (var row = 0; row < 11; row++)
        {
            var freeSlotPos = transform.position + new Vector3(col + 1, -(row + 1), 0);
            if (activeTiles.ContainsValue(freeSlotPos)) continue;
            freeSlots.Add(freeSlotPos);
        }
    }

    public Vector3 GetClosestPosition(Vector3 _point, BubbleTile _tile)
    {
        var nearestPoint = new Vector3(100, 100, 1);
        foreach (var position in freeSlots)
            if (Vector3.Distance(_point, position) < Vector3.Distance(_point, nearestPoint))
                nearestPoint = position;

        freeSlots.Remove(nearestPoint);
        activeTiles.Add(_tile, nearestPoint);
        return nearestPoint;
    }

    private void OnDrawGizmos()
    {
        if (!GameStarted)
        {
            Gizmos.color = Color.magenta;
            for (var c = 0; c < columns; c++)
            for (var r = 0; r < rows; r++)
                Gizmos.DrawWireSphere(transform.position + new Vector3(c + 1, -(r + 1), 0), .5f);
        }

        Gizmos.color = Color.red;

        //Handles.color = Color.cyan;
        foreach (var activeTile in activeTiles.Keys.ToList().Where(_activeTile => _activeTile))
            Gizmos.DrawWireSphere(activeTile.transform.position, .5f);

        //Handles.Label(activeTile.transform.position, activeTile.GetValue().ToString());

        Gizmos.color = Color.green;
        foreach (var tile in freeSlots)
            Gizmos.DrawWireSphere(tile, .55f);
    }

}