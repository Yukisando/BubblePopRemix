﻿using UnityEngine;

public class ParticleManager : MonoBehaviour
{

    //Singleton
    public static ParticleManager Current;

    [SerializeField] private GameObject match;

    private void Awake()
    {
        if (Current != this && Current != null) Destroy(this);
        if (Current == null) Current = this;
    }


    public void PlayMatch(Vector3 _position)
    {
        Instantiate(match, _position, Quaternion.identity, transform);
    }

}