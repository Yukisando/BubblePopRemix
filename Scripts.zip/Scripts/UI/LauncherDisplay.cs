﻿using UnityEngine;

[RequireComponent(typeof(LineRenderer))]
public class LauncherDisplay : MonoBehaviour
{

    //Requirements
    private LineRenderer _lineRenderer;
    private AudioSource _source;
    private SpriteRenderer _spriteRenderer;

    //Line renderer settings
    private Vector3 _lrStartPosition;
    private Vector3 _lrEndPosition;
    [Range(1,4)] public float length = 2.5f;

    private void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
        _source = GetComponent<AudioSource>();
        _lineRenderer = GetComponent<LineRenderer>();
        _lineRenderer.enabled = false;
    }

    public void StartPosition(Vector3 _startPointPosition)
    {
        _lrStartPosition = _startPointPosition;
        _lineRenderer.SetPosition(0, _lrStartPosition);
    }

    public void EndPosition(Vector3 _endPointPosition)
    {
        if(_endPointPosition != _lrEndPosition && !_source.isPlaying) _source.PlayOneShot(_source.clip);
        _lrEndPosition = _endPointPosition;
        _lineRenderer.SetPosition(1, _endPointPosition);
    }

    public void Hide()
    {
        _lineRenderer.enabled = false;
        _spriteRenderer.enabled = true;

        _lineRenderer.SetPosition(0, Vector3.zero);
        _lineRenderer.SetPosition(1, Vector3.zero);
    }

    public void Show()
    {
        _spriteRenderer.enabled = false;
        _lineRenderer.enabled = true;
    }

}