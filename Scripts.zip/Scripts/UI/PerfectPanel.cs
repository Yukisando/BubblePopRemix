﻿using System.Collections;
using UnityEngine;
using UnityEngine.UI;

public class PerfectPanel : MonoBehaviour
{

    private Image _panel;
    private Color _startColor;

    private void Awake()
    {
        _panel = GetComponentInParent<Image>();
        _startColor = _panel.color;
    }

    private void OnEnable()
    {
        _panel.color -= new Color(0,0,0,1);
        StartCoroutine(Show());
    }

    private IEnumerator Show()
    {
        while (_panel.color.a < 1)
        {
            yield return new WaitForEndOfFrame();
            _panel.color += new Color(0, 0, 0, .1f);
        }
        AudioManager.Current.PlayWin();
        _panel.color = _startColor;
        
            yield return new WaitForSeconds(.4f);

            while (_panel.color.a > 0)
            {
                yield return new WaitForEndOfFrame();
                _panel.color -= new Color(0, 0, 0, .1f);
            }

            gameObject.transform.parent.gameObject.SetActive(false);
    }

}