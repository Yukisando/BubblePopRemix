﻿using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{

    //Singleton
    public static UIManager Current;
    private LevelManager _levelManager;

    [SerializeField] private TextMeshProUGUI goalText;
    [SerializeField] private Slider goalBar;
    [SerializeField] private Slider waveBar;
    [SerializeField] private GameObject gameOverPanel;
    [SerializeField] private GameObject winPanel;
    [SerializeField] private GameObject perfectPanel;
    [SerializeField] private Color color_2, color_4, color_8, color_16, color_32, color_64, color_128, color_256, color_512, color_1024, color_2048;

    private void Awake()
    {
        _levelManager = FindObjectOfType<LevelManager>();
        if (Current != this && Current != null) Destroy(this);
        if (Current == null) Current = this;

        goalText.text = "0" + "/" + _levelManager.goal;
        ShowGameOverPanel(false);
        ShowWinPanel(false);
    }

    public void ShowPerfectPanel()
    {
        perfectPanel.SetActive(true);
    }

    public void ShowGameOverPanel(bool _state)
    {
        gameOverPanel.SetActive(_state);
    }

    public void ShowWinPanel(bool _state)
    {
        winPanel.SetActive(_state);
    }

    public void SetProgress(int _amount)
    {
        goalText.text = _amount + "/" + _levelManager.goal;
    }

    public void SetGoal(int _goal)
    {
        goalBar.maxValue = _goal;
    }

    public void SetTimer(float _timer)
    {
        waveBar.value = _timer;
    }

    public void SetTimerMax(float _timerMax)
    {
        waveBar.maxValue = _timerMax;
    }

    public Color GetColor(int _value)
    {
        switch (_value)
        {
            default:
                return color_2;
            case 4:
                return color_4;
            case 8:
                return color_8;
            case 16:
                return color_16;
            case 32:
                return color_32;
            case 64:
                return color_64;
            case 128:
                return color_128;
            case 256:
                return color_256;
            case 512:
                return color_512;
            case 1024:
                return color_1024;
            case 2048:
                return color_2048;
        }
    }

}